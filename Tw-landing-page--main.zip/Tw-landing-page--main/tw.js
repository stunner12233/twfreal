// script.js
document.querySelector('.cta-btn').addEventListener('click', () => {
  console.log('User clicked unlock');
  // You can trigger popup or event here
});
